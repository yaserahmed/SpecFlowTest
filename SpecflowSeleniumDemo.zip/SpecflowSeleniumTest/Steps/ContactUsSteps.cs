﻿using Baseclass.Contrib.SpecFlow.Selenium.NUnit.Bindings;
using OpenQA.Selenium;
using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using SpecFlow.Assist.Dynamic;

namespace SpecflowSeleniumTest
{
   [Binding]
   public class ContactUsSteps
   {
      IWebDriver currentDriver = null;
      [Given(@"I am on the QAWorks Staging site")]
      public void GivenIAmOnTheQAWorksStagingSite()
      {
         //go to to base url
         Browser.Current.Navigate().GoToUrl(ConfigurationManager.AppSettings["seleniumBaseUrl"]);
         currentDriver = Browser.Current;

         //ascertain page is fully loaded

         if (currentDriver.FindElement(By.Name("ctl00$MainContent$NameBox")).Displayed == true)
            Console.WriteLine("Page fully loaded");
         else
            Console.WriteLine("Failed to load page");
      }

      [Then(@"I should be able to contact QAWorks with the following information")]
      public void ThenIShouldBeAbleToContactQAWorksWithTheFollowingInformation(Table table)
      {
         //get table details by column name
         dynamic tableDetail = table.CreateDynamicInstance();
         string name = (string)tableDetail.name;
         string email = (string)tableDetail.email;
         string message = (string)tableDetail.message;

         //send keys for each column
         currentDriver.FindElement(By.Name("ctl00$MainContent$NameBox")).SendKeys(name);
         currentDriver.FindElement(By.Name("ctl00$MainContent$EmailBox")).SendKeys(email);
         currentDriver.FindElement(By.Name("ctl00$MainContent$MessageBox")).SendKeys(message);

         //Submit details
         currentDriver.FindElement(By.ClassName("SendButton")).Submit();

      }

   }
}
